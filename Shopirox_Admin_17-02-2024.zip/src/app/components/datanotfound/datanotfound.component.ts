import { Component } from '@angular/core';

@Component({
  selector: 'app-datanotfound',
  templateUrl: './datanotfound.component.html',
  styleUrls: ['./datanotfound.component.css']
})
export class DatanotfoundComponent {

}
