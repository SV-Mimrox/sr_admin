import { Component } from '@angular/core';

@Component({
  selector: 'app-createiconcomponent',
  templateUrl: './createiconcomponent.component.html',
  styleUrls: ['./createiconcomponent.component.css']
})
export class CreateiconcomponentComponent {

}
