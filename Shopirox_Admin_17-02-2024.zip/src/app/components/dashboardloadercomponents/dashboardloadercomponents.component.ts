import { Component } from '@angular/core';

@Component({
  selector: 'app-dashboardloadercomponents',
  templateUrl: './dashboardloadercomponents.component.html',
  styleUrls: ['./dashboardloadercomponents.component.css']
})
export class DashboardloadercomponentsComponent {

}
